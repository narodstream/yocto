#include <cstdlib>
#include <iostream>


int main() {
  std::cout << "Hello from C++!" << std::endl;
  return EXIT_SUCCESS;
}
