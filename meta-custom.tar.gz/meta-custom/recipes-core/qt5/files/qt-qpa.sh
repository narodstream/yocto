export QT_QPA_PLATFORM=eglfs;wayland
